import os
from flask import Flask
from flask_sqlalchemy import SQLAlchemy

secret_key = os.urandom(24)
app = Flask(__name__)
app.config['SECRET_KEY'] = secret_key
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///../instance/skillshare.db'

db = SQLAlchemy(app)  # Initialize SQLAlchemy with the app

from . import models, routes  # Import models and routes AFTER db is created

with app.app_context():
    db.create_all()  # Create all tables if they don't exist